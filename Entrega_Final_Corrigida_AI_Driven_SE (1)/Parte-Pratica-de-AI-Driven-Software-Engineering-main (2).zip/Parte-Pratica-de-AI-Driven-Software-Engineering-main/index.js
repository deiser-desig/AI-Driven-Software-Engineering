// index.js

/**
 * Gerado com o prompt: 
 * "Crie uma função em Node.js que calcula o valor total de uma assinatura de ferramenta 
 * de colaboração, aplicando um desconto de 20% se o plano for anual e o número de 
 * usuários for maior que 10."
 */
function calcularTotalAssinatura(valorBase, plano, numUsuarios) {
    let total = valorBase * numUsuarios;

    if (plano === 'anual' && numUsuarios > 10) {
        total = total * 0.8; // Aplica 20% de desconto
    }

    return total;
}

module.exports = { calcularTotalAssinatura };

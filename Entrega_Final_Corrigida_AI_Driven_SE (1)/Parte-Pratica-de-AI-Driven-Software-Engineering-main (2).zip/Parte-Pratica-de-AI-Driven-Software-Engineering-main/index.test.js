// index.test.js
const { calcularTotalAssinatura } = require('./index');

/**
 * Gerado com o prompt: 
 * "Gere testes automatizados usando Jest para a função calcularTotalAssinatura, 
 * testando o cenário com desconto e o cenário sem desconto."
 */
test('Deve aplicar 20% de desconto para plano anual com mais de 10 usuários', () => {
    expect(calcularTotalAssinatura(100, 'anual', 11)).toBe(880);
});

test('Não deve aplicar desconto para plano mensal', () => {
    expect(calcularTotalAssinatura(100, 'mensal', 11)).toBe(1100);
});

test('Não deve aplicar desconto para menos de 10 usuários mesmo no anual', () => {
    expect(calcularTotalAssinatura(100, 'anual', 5)).toBe(500);
});

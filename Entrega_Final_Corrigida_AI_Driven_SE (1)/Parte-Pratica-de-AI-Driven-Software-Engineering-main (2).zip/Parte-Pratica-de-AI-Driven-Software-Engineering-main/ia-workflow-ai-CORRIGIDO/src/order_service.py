# Gerado com o prompt:
# "Crie uma função em Python que calcule o valor total de pedidos,
# aplicando um desconto percentual caso o valor total ultrapasse 100 reais."

def calculate_total_order(orders, discount_percentage):
    total = sum(order["price"] for order in orders)

    if total > 100:
        discount = (total * discount_percentage) / 100
        return total - discount

    return total

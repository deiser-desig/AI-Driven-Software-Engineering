# Gerado com o prompt:
# "Crie testes unitários em Python usando pytest
# para validar a função calculate_total_order"

from src.order_service import calculate_total_order


def test_apply_discount_when_total_above_100():
    orders = [{"price": 60}, {"price": 50}]
    result = calculate_total_order(orders, 10)
    assert result == 99


def test_no_discount_when_total_below_100():
    orders = [{"price": 40}, {"price": 50}]
    result = calculate_total_order(orders, 10)
    assert result == 90

# IA na prática: Acelerando o desenvolvimento e garantindo a qualidade com IA

Este projeto demonstra o uso combinado de **GitHub Copilot** e **GitHub Actions**
para acelerar o desenvolvimento de software e garantir qualidade por meio de testes automatizados.

## 🚀 Tecnologias Utilizadas
- Python
- Pytest
- GitHub Copilot
- GitHub Actions

## 🧠 Uso de Inteligência Artificial
O GitHub Copilot foi utilizado para gerar:
- A função principal de negócio
- Os testes unitários automatizados

Os prompts utilizados estão documentados diretamente no código-fonte.

## ⚙️ Integração Contínua (CI/CD)
Foi configurado um pipeline de CI utilizando GitHub Actions que:
- Instala as dependências do projeto
- Executa automaticamente os testes a cada push

## 📊 Status do Build
![Build Status](https://github.com/deiser-desig/Parte-Pratica-de-AI-Driven-Software-Engineering/actions/workflows/ci.yml/badge.svg)

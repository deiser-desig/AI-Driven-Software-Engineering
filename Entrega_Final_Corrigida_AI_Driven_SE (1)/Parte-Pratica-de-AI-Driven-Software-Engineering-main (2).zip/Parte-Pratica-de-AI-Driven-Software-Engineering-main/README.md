
# IA na prática: Acelerando o desenvolvimento e garantindo a qualidade

![CI Pipeline](https://github.com/deiser-desig/Parte-Pratica-de-AI-Driven-Software-Engineering/actions/workflows/ci.yml/badge.svg)

## 🎯 Sobre o Projeto
Este repositório apresenta um protótipo de **fluxo de trabalho assistido por Inteligência Artificial** no desenvolvimento de software.
O objetivo é demonstrar como o uso do **GitHub Copilot** e do **GitHub Actions** contribui para acelerar o desenvolvimento e garantir a qualidade do código.

## 🤖 Uso de IA no Desenvolvimento (GitHub Copilot)
O GitHub Copilot foi utilizado como assistente para a geração de código e de testes automatizados, por meio de prompts específicos documentados diretamente nos arquivos do projeto.

- **Função principal de negócio**: desenvolvida em Python, com comentários no código indicando o prompt utilizado pelo GitHub Copilot.
- **Testes automatizados**: criados com o auxílio do Copilot utilizando o framework `pytest`, também com os prompts devidamente comentados.

Esse uso da IA contribui para maior produtividade e incentivo à escrita de testes desde as etapas iniciais do desenvolvimento.

## 🚀 Pipeline de Integração Contínua (GitHub Actions)
Foi configurado um workflow de **Integração Contínua (CI)** utilizando GitHub Actions, executado automaticamente a cada `push` ou `pull request` na branch principal.

O pipeline realiza as seguintes etapas:
1. Checkout do código-fonte.
2. Configuração do ambiente Python.
3. Instalação das dependências.
4. Execução dos testes automatizados com `pytest`.

Esse processo garante feedback rápido sobre falhas e contribui para a melhoria contínua da qualidade do software.

---

📘 *Trabalho prático de Engenharia de Software Assistida por Inteligência Artificial.*





















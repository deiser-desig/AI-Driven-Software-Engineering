# Engenharia de Software Orientada Por IA

# Análise do Problema Enfrentado Pela Equipe da Empresa Simulada (Contexto do Desafio)

Com o crescimento acelerado da empresa fictícia de colaboração online, a equipe de desenvolvimento passou a enfrentar um dilema clássico da engenharia de software: velocidade versus qualidade. A pressão para entregar novas funcionalidades rapidamente fez com que a cobertura de testes diminuísse e bugs fossem introduzidos com mais frequência. A equipe é formada majoritariamente por desenvolvedores júnior e pleno, que consideram a escrita de testes uma atividade demorada. Além disso, o processo de revisão de código se tornou um gargalo, atrasando entregas e impactando negativamente o roadmap prometido a equipe de marketing.
Os principais problemas identificados foram: Desenvolvimento lento devido à escrita manual de código repetitivo, baixa cobertura de testes automatizados; descoberta tardia de bugs, muitas vezes em produção e inconsistência de padrões no código.

# Discussão Conceitual Sobre o Papel da IA no Ciclo de Desenvolvimento de Software, Especialmente em Geração de Código, Testes e CI/CD.

A Inteligência Artificial tem se tornado uma aliada estratégica no desenvolvimento moderno de software. Ferramentas como o GitHub Copilot auxiliam na geração de código, sugestões de boas práticas, criação de testes automatizados e padronização da base de código. No contexto de CI/CD, o GitHub Actions permite automatizar pipelines de integração contínua, garantindo que testes sejam executados a cada alteração no código, reduzindo falhas em produção e acelerando o ciclo de feedback.
O uso combinado dessas ferramentas traz benefícios como: Aumento da produtividade, redução de erros humanos, melhoria da qualidade do código, padronização de soluções, feedback rápido para o time de desenvolvimento.

# Pesquisa De Um Caso Real De Uma Empresa De Desenvolvimento Que Utilizou GitHub Copilot ou GitHub Actions Para Melhorar Velocidade E Qualidade No Desenvolvimento.

Segundo estudos divulgados pelo próprio GitHub, equipes que utilizam o GitHub Copilot conseguem desenvolver funcionalidades até 55% mais rápido, além de apresentarem maior satisfação durante o desenvolvimento. Empresas como Shopify e Microsoft relataram ganhos significativos em produtividade e qualidade de código ao adotar ferramentas de IA e automação em seus pipelines de desenvolvimento. O GitHub Actions também é amplamente utilizado por empresas modernas para automatizar testes, builds e deploys, reduzindo drasticamente falhas humanas e aumentando a confiabilidade das entregas.

# Referências:

https://github.com/features/copilot 

https://github.blog 

https://www.microsoft.com

Continuous Delivery: Reliable Software Releases through Build, Test, and Deployment Automation.
Addison-Wesley, 2010.

https://martinfowler.com/articles/continuousIntegration.html

https://docs.github.com/actions

Software Engineering: A Practitioner’s Approach.
McGraw-Hill, 8ª edição, 2015.

Code Complete: A Practical Handbook of Software Construction.
Microsoft Press, 2ª edição, 2004.

https://www.technologyreview.com
